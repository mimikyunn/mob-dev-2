import UIKit

final class ConfirmationViewController: UIViewController {
    @IBOutlet weak var messageLabel: UILabel!
    
    var name: String = "Club Member"
    var wantsReminders: Bool = false
    var role: String = "Member"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Confirmation"
        
        let remindersText = wantsReminders ? "ON" : "OFF"
        let message = """
            Thanks, \(name)!
            You've signed up as a \(role).
            Meeting reminders: \(remindersText)
            """
        messageLabel.text = message
        messageLabel.numberOfLines = 0
    }
}
