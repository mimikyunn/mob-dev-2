import UIKit
import PhotosUI

private enum DefaultsKey {
    static let studentName = "studentName"
    static let notificationsEnabled = "notificationsEnabled"
    static let selectedRoleIndex = "selectedRoleIndex"
}

final class ViewController: UIViewController, PHPickerViewControllerDelegate {
    @IBOutlet weak var eventDatePicker: UIDatePicker!
    @IBOutlet weak var guestStepper: UIStepper!
    @IBOutlet weak var roleSegmentedControl: UISegmentedControl!
    @IBOutlet weak var notifySwitch: UISwitch!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var subtitleLabel: UILabel!
    @IBOutlet weak var guestLabel: UILabel!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var removePhotoButton: UIButton?

    private let profilePhotoFileName = "profilePhoto.jpg"

    override func viewDidLoad() {
        super.viewDidLoad()

        titleLabel.text = "Campus Companion"
        subtitleLabel.text = "Your Campus, In Your Pocket"

        configureProfileImageView()
        restorePreferences()
        loadProfileImageFromDisk()
        updateRemovePhotoButton()
    }

    @IBAction func changePhotoTapped(_ sender: UIButton) {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 1

        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = self
        present(picker, animated: true)
    }

    @IBAction func removePhotoTapped(_ sender: UIButton) {
        guard let fileURL = profilePhotoURL else {
            updateRemovePhotoButton()
            return
        }

        do {
            if FileManager.default.fileExists(atPath: fileURL.path) {
                try FileManager.default.removeItem(at: fileURL)
            }
        } catch {
            print("Could not remove profile photo: " + error.localizedDescription)
        }

        profileImageView.image = UIImage(systemName: "person.crop.circle")
        updateRemovePhotoButton()
    }

    func picker(
        _ picker: PHPickerViewController,
        didFinishPicking results: [PHPickerResult]
    ) {
        picker.dismiss(animated: true)

        guard let result = results.first else {
            return
        }

        result.itemProvider.loadObject(ofClass: UIImage.self) { [weak self] object, error in
            guard let self, let image = object as? UIImage else {
                if let error {
                    print("Could not load profile photo: " + error.localizedDescription)
                }
                return
            }

            DispatchQueue.main.async {
                self.profileImageView.image = image
                self.saveProfileImageToDisk(image)
                self.updateRemovePhotoButton()
            }
        }
    }

    private var profilePhotoURL: URL? {
        FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first?.appendingPathComponent(profilePhotoFileName)
    }

    private func configureProfileImageView() {
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.clipsToBounds = true
        profileImageView.layer.cornerRadius = 50
        profileImageView.image = UIImage(systemName: "person.crop.circle")
        profileImageView.tintColor = .secondaryLabel
        updateGuestCountLabel()
    }

    @IBAction func guestStepperChanged(_ sender: UIStepper) {
        updateGuestCountLabel()
    }

    private func updateGuestCountLabel() {
        guestLabel.text = "Number of Guests: " + String(Int(guestStepper.value))
    }

    private func saveProfileImageToDisk(_ image: UIImage) {
        guard let data = image.jpegData(compressionQuality: 0.8),
              let fileURL = profilePhotoURL else {
            return
        }

        do {
            try data.write(to: fileURL, options: .atomic)
        } catch {
            print("Could not save profile photo: " + error.localizedDescription)
        }
    }

    private func loadProfileImageFromDisk() {
        guard let fileURL = profilePhotoURL,
              let image = UIImage(contentsOfFile: fileURL.path) else {
            return
        }

        profileImageView.image = image
    }

    private func updateRemovePhotoButton() {
        removePhotoButton?.isEnabled = profilePhotoURL.map {
            FileManager.default.fileExists(atPath: $0.path)
        } ?? false
    }

    @IBAction func getStartedTapped(_ sender: UIButton) {
        nameTextField.resignFirstResponder()

        let enteredName = nameTextField.text ?? ""
        UserDefaults.standard.set(enteredName, forKey: DefaultsKey.studentName)
        UserDefaults.standard.set(
            notifySwitch.isOn,
            forKey: DefaultsKey.notificationsEnabled
        )
        UserDefaults.standard.set(
            roleSegmentedControl.selectedSegmentIndex,
            forKey: DefaultsKey.selectedRoleIndex
        )

        performSegue(withIdentifier: "ShowDetailSegue", sender: self)
    }

    @IBAction func resetPreferencesTapped(_ sender: UIButton) {
        UserDefaults.standard.removeObject(forKey: DefaultsKey.studentName)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.notificationsEnabled)
        UserDefaults.standard.removeObject(forKey: DefaultsKey.selectedRoleIndex)

        nameTextField.text = ""
        notifySwitch.isOn = false
        roleSegmentedControl.selectedSegmentIndex = 0
    }

    private func restorePreferences() {
        nameTextField.text = UserDefaults.standard.string(
            forKey: DefaultsKey.studentName
        ) ?? ""
        notifySwitch.isOn = UserDefaults.standard.bool(
            forKey: DefaultsKey.notificationsEnabled
        )
        roleSegmentedControl.selectedSegmentIndex = UserDefaults.standard.integer(
            forKey: DefaultsKey.selectedRoleIndex
        )
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowDetailSegue",
              let destination = segue.destination as? DetailViewController else {
            return
        }

        let enteredName = nameTextField.text ?? ""
        let role = roleSegmentedControl.selectedSegmentIndex == 0
            ? "Student"
            : "Faculty"

        destination.studentName = enteredName.isEmpty ? role : enteredName
        destination.selectedRole = role
        destination.notificationsEnabled = notifySwitch.isOn
        destination.eventDate = eventDatePicker.date
        destination.guestCount = guestStepper.value > 0
            ? Int(guestStepper.value)
            : 1
    }
}
