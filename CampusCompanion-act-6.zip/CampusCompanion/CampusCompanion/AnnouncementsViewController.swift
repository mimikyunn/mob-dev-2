import UIKit
import CoreData

private enum RemoteEndpoint {
    static let announcements = URL(
        string: "https://api.restful-api.dev/objects"
    )!
}

final class AnnouncementsViewController: UITableViewController {
    private var announcements: [PersistentAnnouncement] = []
    private var selectedAnnouncement: CampusAnnouncement?

    private var context: NSManagedObjectContext {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            fatalError("AppDelegate is unavailable")
        }
        return appDelegate.persistentContainer.viewContext
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Campus Announcements"
        configureMoreMenu()
        tableView.register(AnnouncementCell.self, forCellReuseIdentifier: "AnnouncementCell")
        tableView.contentInsetAdjustmentBehavior = .automatic
        tableView.contentInset = UIEdgeInsets(top: 8, left: 0, bottom: 0, right: 0)
        tableView.scrollIndicatorInsets = tableView.contentInset
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 96
        seedInitialAnnouncementsIfNeeded()
        loadAnnouncements()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }

    private func configureMoreMenu() {
        let refreshAction = UIAction(
            title: "Refresh",
            image: UIImage(systemName: "arrow.clockwise")
        ) { [weak self] _ in
            guard let self else { return }
            self.refreshTapped(UIBarButtonItem())
        }

        let addAction = UIAction(
            title: "Add Announcement",
            image: UIImage(systemName: "plus")
        ) { [weak self] _ in
            guard let self else { return }
            self.addAnnouncementTapped(UIBarButtonItem())
        }

        let menu = UIMenu(title: "", children: [refreshAction, addAction])
        let moreButton = UIBarButtonItem(
            image: UIImage(systemName: "line.3.horizontal"),
            menu: menu
        )
        moreButton.accessibilityLabel = "More actions"
        navigationItem.rightBarButtonItem = moreButton
    }

    @IBAction func backTapped(_ sender: UIBarButtonItem) {
        navigationController?.popViewController(animated: true)
    }

    @IBAction func refreshTapped(_ sender: UIBarButtonItem) {
        sender.isEnabled = false
        fetchAnnouncementsFromServer { [weak sender] in
            sender?.isEnabled = true
        }
    }

    private func fetchAnnouncementsFromServer(completion: @escaping () -> Void = {}) {
        let task = URLSession.shared.dataTask(with: RemoteEndpoint.announcements) {
            [weak self] data, response, error in
            if let error {
                print("Network error: " + error.localizedDescription)
                DispatchQueue.main.async {
                    completion()
                }
                return
            }

            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print("Unexpected server response.")
                DispatchQueue.main.async {
                    completion()
                }
                return
            }

            guard let data else {
                print("Server returned no data.")
                DispatchQueue.main.async {
                    completion()
                }
                return
            }

            print(String(data: data, encoding: .utf8) ?? "Unable to print server response.")

            do {
                let decodedAnnouncements = try JSONDecoder().decode(
                    [AnnouncementDTO].self,
                    from: data
                )

                DispatchQueue.main.async { [weak self] in
                    guard let self else {
                        completion()
                        return
                    }

                    self.replaceAnnouncements(with: decodedAnnouncements)
                    self.showNetworkConfirmationAlert(byteCount: data.count)
                    completion()
                }
            } catch {
                print("Decoding error: " + error.localizedDescription)
                DispatchQueue.main.async {
                    completion()
                }
            }
        }

        task.resume()
    }

    private func replaceAnnouncements(with dtos: [AnnouncementDTO]) {
        let existing = (try? context.fetch(PersistentAnnouncement.fetchRequest())) ?? []
        existing.forEach(context.delete)

        dtos.forEach { dto in
            let announcement = PersistentAnnouncement(context: context)
            announcement.title = dto.title
            announcement.date = dto.date
            announcement.category = dto.category
            announcement.location = dto.location
            announcement.priority = dto.priorityLevel
            announcement.priorityLevel = dto.priorityLevel
            announcement.postedBy = dto.category
        }

        try? context.save()
        loadAnnouncements()
    }

    private func showNetworkConfirmationAlert(byteCount: Int) {
        let alert = UIAlertController(
            title: "Server Reached",
            message: "Received " + String(byteCount) +
                " bytes from the announcements endpoint.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    override func tableView(
        _ tableView: UITableView,
        numberOfRowsInSection section: Int
    ) -> Int {
        announcements.count
    }

    override func tableView(
        _ tableView: UITableView,
        cellForRowAt indexPath: IndexPath
    ) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(
            withIdentifier: "AnnouncementCell",
            for: indexPath
        ) as? AnnouncementCell else {
            return UITableViewCell()
        }

        cell.configure(with: value(for: announcements[indexPath.row]))
        return cell
    }

    override func tableView(
        _ tableView: UITableView,
        didSelectRowAt indexPath: IndexPath
    ) {
        tableView.deselectRow(at: indexPath, animated: true)
        selectedAnnouncement = value(for: announcements[indexPath.row])
        performSegue(
            withIdentifier: "ShowAnnouncementDetailSegue",
            sender: self
        )
    }

    override func tableView(
        _ tableView: UITableView,
        commit editingStyle: UITableViewCell.EditingStyle,
        forRowAt indexPath: IndexPath
    ) {
        guard editingStyle == .delete else {
            return
        }

        let announcement = announcements.remove(at: indexPath.row)
        context.delete(announcement)
        try? context.save()
        tableView.deleteRows(at: [indexPath], with: .automatic)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard segue.identifier == "ShowAnnouncementDetailSegue",
              let destination = segue.destination as? DetailViewController,
              let selectedAnnouncement else {
            return
        }

        destination.announcement = selectedAnnouncement
    }

    @IBAction func addAnnouncementTapped(_ sender: UIBarButtonItem) {
        let alert = UIAlertController(
            title: "New Announcement",
            message: "Enter a title and category.",
            preferredStyle: .alert
        )
        alert.addTextField { $0.placeholder = "Title" }
        alert.addTextField { $0.placeholder = "Category" }

        let saveAction = UIAlertAction(title: "Save", style: .default) {
            [weak self, weak alert] _ in
            guard let self,
                  let title = alert?.textFields?[0].text?
                    .trimmingCharacters(in: .whitespacesAndNewlines),
                  !title.isEmpty,
                  let category = alert?.textFields?[1].text?
                    .trimmingCharacters(in: .whitespacesAndNewlines),
                  !category.isEmpty else {
                return
            }

            let announcement = PersistentAnnouncement(context: self.context)
            announcement.title = title
            announcement.category = category
            announcement.date = DateFormatter.localizedString(
                from: Date(),
                dateStyle: .long,
                timeStyle: .none
            )
            announcement.location = "Campus"
            announcement.priority = "Normal"
            announcement.priorityLevel = "Normal"
            announcement.postedBy = category

            try? self.context.save()
            self.loadAnnouncements()
        }

        alert.addAction(saveAction)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }

    private func seedInitialAnnouncementsIfNeeded() {
        let request = PersistentAnnouncement.fetchRequest()
        let existingCount = (try? context.count(for: request)) ?? 0
        guard existingCount == 0 else {
            return
        }

        CampusAnnouncement.sampleAnnouncements.forEach { sample in
            let announcement = PersistentAnnouncement(context: context)
            announcement.title = sample.title
            announcement.date = sample.date
            announcement.category = sample.category
            announcement.location = sample.location
            announcement.priority = sample.priority
            announcement.priorityLevel = sample.priorityLevel
            announcement.postedBy = sample.postedBy
        }

        try? context.save()
    }

    private func loadAnnouncements() {
        let request = PersistentAnnouncement.fetchRequest()
        request.sortDescriptors = [
            NSSortDescriptor(key: "date", ascending: true)
        ]
        announcements = (try? context.fetch(request)) ?? []
        tableView.reloadData()
    }

    private func value(for announcement: PersistentAnnouncement) -> CampusAnnouncement {
        CampusAnnouncement(
            title: announcement.title,
            date: announcement.date,
            category: announcement.category,
            location: announcement.location,
            priority: announcement.priority,
            priorityLevel: announcement.priorityLevel,
            postedBy: announcement.postedBy
        )
    }
}
