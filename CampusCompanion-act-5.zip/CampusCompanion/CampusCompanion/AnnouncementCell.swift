import UIKit

class AnnouncementCell: UITableViewCell {

    @IBOutlet weak var categoryIconImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!

    func configure(with announcement: CampusAnnouncement) {
        let category = announcement.category ?? ""
        let date = announcement.date ?? ""
        let location = announcement.location.flatMap { $0.isEmpty ? nil : $0 }
            ?? "Location unavailable"
        let priorityLevel = announcement.priorityLevel.flatMap { $0.isEmpty ? nil : $0 }
            ?? "Normal"

        titleLabel.text = announcement.title
        dateLabel.numberOfLines = 0
        dateLabel.text = """
        \(category) • \(date)
        Location: \(location) • Priority: \(priorityLevel)
        """
        categoryIconImageView.image = UIImage(systemName: "megaphone.fill")
    }
}
