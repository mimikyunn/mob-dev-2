import UIKit

final class AnnouncementDetailViewController: UIViewController {
    private let announcementTitle: String
    private let announcementDate: String
    private let announcementCategory: String
    private let announcementLocation: String
    private let announcementPriority: String

    init(announcement: CampusAnnouncement) {
        announcementTitle = announcement.title ?? "Announcement"
        announcementDate = announcement.date ?? "Date unavailable"
        announcementCategory = announcement.category ?? "Campus"
        announcementLocation = announcement.location.flatMap { $0.isEmpty ? nil : $0 }
            ?? "Location unavailable"
        announcementPriority = announcement.priorityLevel.flatMap { $0.isEmpty ? nil : $0 }
            ?? "Normal"
        super.init(nibName: nil, bundle: nil)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        title = announcementCategory
        view.backgroundColor = .systemBackground
        configureDetails()
    }

    private func configureDetails() {
        let titleLabel = makeLabel(text: announcementTitle)
        let dateLabel = makeLabel(text: announcementDate)
        let locationLabel = makeLabel(text: "Location: \(announcementLocation)")
        let priorityLabel = makeLabel(text: "Priority: \(announcementPriority)")
        let postedByLabel = makeLabel(text: "Posted by: \(announcementCategory) Office")

        let detailsStack = UIStackView(
            arrangedSubviews: [
                titleLabel,
                dateLabel,
                locationLabel,
                priorityLabel,
                postedByLabel
            ]
        )
        detailsStack.axis = .vertical
        detailsStack.alignment = .center
        detailsStack.spacing = 4
        detailsStack.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(detailsStack)

        let safeArea = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            detailsStack.centerXAnchor.constraint(equalTo: safeArea.centerXAnchor),
            detailsStack.centerYAnchor.constraint(equalTo: safeArea.centerYAnchor),
            detailsStack.leadingAnchor.constraint(greaterThanOrEqualTo: safeArea.leadingAnchor, constant: 24),
            detailsStack.trailingAnchor.constraint(lessThanOrEqualTo: safeArea.trailingAnchor, constant: -24)
        ])
    }

    private func makeLabel(text: String) -> UILabel {
        let label = UILabel()
        label.text = text
        label.font = .preferredFont(forTextStyle: .title2)
        label.adjustsFontForContentSizeCategory = true
        label.numberOfLines = 0
        label.textAlignment = .center
        return label
    }
}
