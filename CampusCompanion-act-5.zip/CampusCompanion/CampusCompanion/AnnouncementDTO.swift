import Foundation

struct AnnouncementDTO: Codable {
    let title: String
    let date: String
    let category: String
    let location: String
    let priorityLevel: String

    private enum CodingKeys: String, CodingKey {
        case title
        case date
        case category
        case location
        case priority
        case priorityLevel
        case prioritySnakeCase = "priority_level"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        title = try container.decode(String.self, forKey: .title)
        date = try container.decode(String.self, forKey: .date)
        category = try container.decode(String.self, forKey: .category)
        location = try container.decodeIfPresent(String.self, forKey: .location) ?? "Location unavailable"
        priorityLevel =
            try container.decodeIfPresent(String.self, forKey: .priorityLevel)
            ?? container.decodeIfPresent(String.self, forKey: .priority)
            ?? container.decodeIfPresent(String.self, forKey: .prioritySnakeCase)
            ?? "Normal"
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encode(title, forKey: .title)
        try container.encode(date, forKey: .date)
        try container.encode(category, forKey: .category)
        try container.encode(location, forKey: .location)
        try container.encode(priorityLevel, forKey: .priority)
    }
}
